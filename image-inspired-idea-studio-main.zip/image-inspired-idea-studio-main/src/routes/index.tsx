import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import {
  ArrowRight, Github, Linkedin, Mail, Phone, Menu, X, Code2, Brain, Puzzle, Globe,
  Database, Wrench, Cpu, GraduationCap, Plane, BookOpen, MessageCircle, Sparkles,
} from "lucide-react";
import profileAsset from "@/assets/profile.jpg.asset.json";

const TITLE = "Prachi Katiyar | Aspiring Software Developer";
const DESC =
  "Explore Prachi Katiyar's software development portfolio, featuring AI-assisted software projects, web development interests, programming skills, and Data Structures and Algorithms.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const EMAIL = "katiyarprachi366@gmail.com";
const GITHUB = "https://github.com/Prachi-katiyar366";
const LINKEDIN = "https://www.linkedin.com/in/prachi-katiyar-b80330383";
const PHONE = "8176918894";
const SHOW_PHONE = true;

const NAV = [
  ["home", "Home"], ["about", "About"], ["skills", "Skills"], ["projects", "Projects"],
  ["interests", "Interests"], ["education", "Education"], ["journey", "Journey"], ["contact", "Contact"],
] as const;

const ROLES = [
  "Aspiring Software Developer",
  "DSA & Problem-Solving Enthusiast",
  "AI-Integrated Software Builder",
  "Web Development Learner",
];

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("in")),
      { threshold: 0.12 },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

function useActiveSection() {
  const [active, setActive] = useState("home");
  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: "-45% 0px -50% 0px" },
    );
    NAV.forEach(([id]) => { const el = document.getElementById(id); if (el) io.observe(el); });
    return () => io.disconnect();
  }, []);
  return active;
}

function Ext({ href, children, className }: { href: string; children: ReactNode; className?: string }) {
  return <a href={href} target="_blank" rel="noopener noreferrer" className={className}>{children}</a>;
}

function Section({ id, eyebrow, title, subtitle, children }: { id: string; eyebrow: string; title: string; subtitle?: string; children: ReactNode }) {
  return (
    <section id={id} className="scroll-mt-24 px-6 py-24 md:px-12">
      <div className="mx-auto max-w-6xl">
        <div className="reveal mb-12 max-w-2xl">
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-primary-glow">{eyebrow}</p>
          <h2 className="mt-3 text-3xl font-semibold md:text-5xl">{title}</h2>
          {subtitle && <p className="mt-4 text-muted-foreground">{subtitle}</p>}
        </div>
        {children}
      </div>
    </section>
  );
}

function Index() {
  useReveal();
  const active = useActiveSection();
  const [open, setOpen] = useState(false);
  const [role, setRole] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setRole((r) => (r + 1) % ROLES.length), 2600);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="min-h-screen overflow-x-hidden">
      {/* NAV */}
      <header className="fixed inset-x-0 top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-md">
        <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4 md:px-12" aria-label="Main">
          <a href="#home" className="font-display text-xl font-semibold">
            Prachi<span className="text-primary-glow">.</span>
          </a>
          <a href={`mailto:${EMAIL}`} className="hidden text-sm text-muted-foreground hover:text-foreground lg:block">{EMAIL}</a>
          <ul className="hidden items-center gap-6 md:flex">
            {NAV.map(([id, label]) => (
              <li key={id}>
                <a href={`#${id}`} className={`relative text-sm transition-colors ${active === id ? "text-foreground" : "text-muted-foreground hover:text-foreground"}`}>
                  {label}
                  <span className={`absolute -bottom-1.5 left-0 h-0.5 bg-gradient-primary transition-all ${active === id ? "w-full" : "w-0"}`} />
                </a>
              </li>
            ))}
          </ul>
          <button className="md:hidden" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} onClick={() => setOpen(!open)}>
            {open ? <X /> : <Menu />}
          </button>
        </nav>
        {open && (
          <ul className="border-t border-border bg-background px-6 py-4 md:hidden">
            {NAV.map(([id, label]) => (
              <li key={id}><a href={`#${id}`} onClick={() => setOpen(false)} className="block py-3 text-muted-foreground hover:text-foreground">{label}</a></li>
            ))}
          </ul>
        )}
      </header>

      {/* HERO — inspired by the reference: name left, portrait center, intro right */}
      <section id="home" className="relative flex min-h-screen items-center px-6 pt-28 pb-16 md:px-12">
        <div className="bg-grid pointer-events-none absolute inset-0" />
        <div className="pointer-events-none absolute left-1/2 top-1/2 h-[520px] w-[520px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/20 blur-[120px]" />
        <div className="relative mx-auto grid w-full max-w-6xl items-center gap-12 lg:grid-cols-[1.1fr_auto_1fr]">
          <div className="reveal">
            <p className="font-mono text-xs uppercase tracking-[0.25em] text-primary-glow">Computer Science Engineering Student</p>
            <h1 className="mt-5 font-serif text-5xl font-bold leading-[1.05] md:text-6xl">
              Hi,<br />I'm <span className="text-gradient">Prachi Katiyar</span>
            </h1>
            <p key={role} className="mt-5 font-display text-xl text-foreground/90 animate-in fade-in slide-in-from-bottom-2 duration-500" aria-live="polite">
              {ROLES[role]}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#projects" className="group inline-flex items-center gap-3 rounded-lg bg-gradient-primary py-2 pl-5 pr-2 font-medium text-primary-foreground shadow-glow transition active:scale-95">
                Explore My Projects
                <span className="rounded-md bg-primary-foreground/20 p-1.5 transition group-hover:translate-x-0.5"><ArrowRight size={16} /></span>
              </a>
              <a href="#contact" className="inline-flex items-center rounded-lg border border-border px-5 py-2 font-medium transition hover:border-primary hover:bg-accent">Let's Connect</a>
            </div>
            <div className="mt-10 flex items-center gap-5 text-muted-foreground">
              <Ext href={GITHUB} className="hover:text-primary-glow"><Github size={20} aria-label="GitHub" /></Ext>
              <Ext href={LINKEDIN} className="hover:text-primary-glow"><Linkedin size={20} aria-label="LinkedIn" /></Ext>
              <a href={`mailto:${EMAIL}`} className="hover:text-primary-glow"><Mail size={20} aria-label="Email" /></a>
            </div>
          </div>

          <div className="reveal relative mx-auto">
            <div className="relative h-72 w-72 overflow-hidden rounded-full border border-primary/40 bg-card shadow-glow md:h-80 md:w-80">
              <img
                src={profileAsset.url}
                alt="Prachi Katiyar"
                width={320}
                height={320}
                className="h-full w-full object-cover object-[50%_22%]"
              />
              <div className="pointer-events-none absolute inset-0 rounded-full ring-1 ring-inset ring-primary/30" />
            </div>
            {[["C++", "-left-6 top-6"], ["React", "-right-8 top-16"], ["DSA", "-left-10 bottom-16"], ["AI", "-right-4 bottom-4"]].map(([l, pos], i) => (
              <span key={l} className={`glass animate-float absolute ${pos} rounded-lg px-3 py-1.5 font-mono text-xs text-primary-glow`} style={{ animationDelay: `${i * 0.8}s` }}>{l}</span>
            ))}
            <span className="absolute -top-6 right-6 h-12 w-12 rounded-full border-2 border-primary-glow" />
            <span className="absolute -top-8 right-3 h-5 w-5 rounded-full border-2 border-primary" />
          </div>

          <div className="reveal lg:pl-6">
            <p className="text-sm text-primary-glow">Focused on</p>
            <p className="mt-3 font-display text-2xl leading-snug">Building intelligent solutions. Solving real-world problems.</p>
            <p className="mt-5 text-muted-foreground">
              I build practical software projects, explore intelligent technologies, and continuously improve my problem-solving skills.
            </p>
            <p className="mt-8 inline-flex items-center gap-2 rounded-full border border-border px-3 py-1.5 font-mono text-xs text-muted-foreground">
              <span className="h-2 w-2 animate-pulse rounded-full bg-success" /> Currently learning, building, and improving.
            </p>
          </div>
        </div>
        <a href="#contact" className="absolute bottom-8 right-6 hidden items-center gap-2 text-sm md:right-12 md:flex">
          Let's Chat <MessageCircle className="text-primary-glow" size={22} />
        </a>
      </section>

      {/* ABOUT */}
      <Section id="about" eyebrow="01 / About" title="A Little About Me" subtitle="Curious mind. Continuous learner. Practical builder.">
        <div className="grid gap-10 lg:grid-cols-[1.2fr_1fr]">
          <div className="reveal space-y-4 text-muted-foreground">
            <p>I'm Prachi Katiyar, a Computer Science and Engineering student at Kanpur Institute of Technology. I'm passionate about web development, Data Structures and Algorithms, and building software that addresses practical problems.</p>
            <p>Currently, I'm working on SKYRECON AI, an AI-assisted flight data investigation support system, and an AI-Assisted Library Management System. These projects help me explore real-world software development challenges while strengthening my programming fundamentals.</p>
            <p>I believe consistent learning, logical thinking, and hands-on experimentation are essential to becoming a capable software developer.</p>
            <div className="glass mt-6 rounded-xl p-5">
              <p className="font-mono text-xs uppercase tracking-widest text-primary-glow">My Development Philosophy</p>
              <p className="mt-2 font-display text-lg text-foreground">Learn the fundamentals. Build real projects. Test assumptions. Improve continuously.</p>
            </div>
          </div>
          <div className="grid gap-4">
            {[
              [Puzzle, "Problem-Solving", ["Developing logical thinking", "Practicing DSA concepts", "Writing clear, efficient code"]],
              [Code2, "Software Development", ["Building practical applications", "Exploring web technologies", "Improving software design"]],
              [Brain, "AI-Integrated Solutions", ["AI-assisted software workflows", "Technology-driven project concepts", "Responsible, useful AI systems"]],
            ].map(([Icon, t, items]) => {
              const I = Icon as typeof Puzzle;
              return (
                <div key={t as string} className="reveal glass rounded-xl p-5 transition hover:border-primary/60">
                  <div className="flex items-center gap-3"><I className="text-primary-glow" size={20} /><h3 className="font-semibold">{t as string}</h3></div>
                  <ul className="mt-3 space-y-1 text-sm text-muted-foreground">{(items as string[]).map((x) => <li key={x}>· {x}</li>)}</ul>
                </div>
              );
            })}
          </div>
        </div>
      </Section>

      {/* SKILLS */}
      <Section id="skills" eyebrow="02 / Skills" title="My Technical Toolkit" subtitle="Technologies I use and concepts I'm actively developing through practice and projects.">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {[
            [Code2, "Programming Languages", ["C", "C++", "Java"]],
            [Globe, "Web Development", ["HTML5", "CSS3", "JavaScript", "React"]],
            [Puzzle, "CS Fundamentals", ["Data Structures & Algorithms", "Object-Oriented Programming"]],
            [Database, "Databases", ["MySQL"]],
            [Cpu, "AI & Dev Technologies", ["Model Context Protocol (MCP)"]],
            [Wrench, "Development Tools", ["Git", "GitHub", "VS Code"]],
          ].map(([Icon, t, items]) => {
            const I = Icon as typeof Code2;
            return (
              <div key={t as string} className="reveal glass rounded-xl p-6 transition hover:-translate-y-1 hover:border-primary/60">
                <I className="text-primary-glow" />
                <h3 className="mt-4 font-semibold">{t as string}</h3>
                <div className="mt-4 flex flex-wrap gap-2">
                  {(items as string[]).map((s) => <span key={s} className="rounded-md border border-border bg-secondary px-2.5 py-1 font-mono text-xs">{s}</span>)}
                </div>
              </div>
            );
          })}
        </div>
      </Section>

      {/* PROJECTS */}
      <Section id="projects" eyebrow="03 / Projects" title="Projects I'm Building" subtitle="Turning technical curiosity into practical software solutions.">
        <div className="grid gap-8 lg:grid-cols-2">
          <ProjectCard
            icon={<Plane size={40} />}
            category="AI-Assisted Aviation Investigation Support"
            title="SKYRECON AI — Flight Data Rescue System"
            vision="Reconstructing Data, Revealing the Truth."
            desc="An AI-assisted flight data analysis system designed to support aviation accident investigations — helping investigators validate available records, identify missing or inconsistent data, flag anomalous parameters, and reconstruct timelines from available evidence. It supports investigators; it does not determine causes."
            points={["Flight data validation", "Altitude & airspeed anomaly flagging", "Timeline reconstruction", "File-hash integrity checks", "Structured investigation reports"]}
            tags={["AI-Assisted Analysis", "Flight Data", "Anomaly Detection", "Data Integrity"]}
          />
          <ProjectCard
            icon={<BookOpen size={40} />}
            category="Intelligent Library Software"
            title="AI-Assisted Library Management System"
            desc="An AI-assisted library management application focused on organizing library operations and making library information easier to manage — reflecting my interest in database-driven applications and intelligent features in everyday systems."
            points={["Book catalog management", "Student & library records", "Search and retrieval", "Database-backed storage"]}
            tags={["Database Management", "Software Development", "Library Automation"]}
          />
        </div>
        <div className="reveal glass mt-8 flex flex-col items-start justify-between gap-4 rounded-xl p-6 sm:flex-row sm:items-center">
          <div className="flex items-center gap-4"><Github className="text-primary-glow" size={28} /><div><p className="font-semibold">Follow my work on GitHub</p><p className="text-sm text-muted-foreground">github.com/Prachi-katiyar366</p></div></div>
          <Ext href={GITHUB} className="inline-flex items-center gap-2 rounded-lg bg-gradient-primary px-5 py-2.5 font-medium text-primary-foreground">Visit My GitHub <ArrowRight size={16} /></Ext>
        </div>
      </Section>

      {/* INTERESTS */}
      <Section id="interests" eyebrow="04 / Interests" title="What I'm Interested In">
        <div className="grid gap-5 md:grid-cols-3">
          {[
            [Puzzle, "Problem-Solving & DSA", "Practicing algorithms and data structures, analyzing problems, and improving code efficiency."],
            [Sparkles, "AI-Integrated Software", "Exploring AI-assisted workflows and learning to integrate AI into practical applications responsibly."],
            [Globe, "Web Development", "Creating responsive interfaces and functional, user-friendly web experiences."],
          ].map(([Icon, t, d]) => {
            const I = Icon as typeof Puzzle;
            return (
              <div key={t as string} className="reveal glass rounded-xl p-6 transition hover:border-primary/60">
                <I className="text-primary-glow" /><h3 className="mt-4 font-semibold">{t as string}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{d as string}</p>
              </div>
            );
          })}
        </div>
      </Section>

      {/* EDUCATION */}
      <Section id="education" eyebrow="05 / Education" title="Education">
        <div className="reveal glass relative max-w-3xl rounded-2xl p-8 pl-10">
          <span className="absolute left-0 top-8 bottom-8 w-1 rounded-r bg-gradient-primary" />
          <div className="flex items-start gap-5">
            <GraduationCap className="mt-1 shrink-0 text-primary-glow" size={32} />
            <div>
              <h3 className="text-2xl font-semibold">Kanpur Institute of Technology</h3>
              <p className="mt-1 text-muted-foreground">Bachelor of Technology (B.Tech) · Computer Science and Engineering</p>
              <div className="mt-4 flex flex-wrap gap-3 font-mono text-xs">
                <span className="rounded-md border border-border px-2.5 py-1">2025 – 2029</span>
                <span className="rounded-md border border-primary/50 px-2.5 py-1 text-primary-glow">Currently pursuing</span>
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* JOURNEY */}
      <Section id="journey" eyebrow="06 / Journey" title="Currently Learning. Constantly Building.">
        <ol className="relative grid gap-6 border-l border-border pl-6 md:grid-cols-4 md:border-l-0 md:border-t md:pl-0 md:pt-8 lg:grid-cols-7">
          {["C, C++ & Java fundamentals", "Data Structures & Algorithms", "Object-Oriented Programming", "HTML, CSS, JS & React", "MySQL & data-driven apps", "MCP & AI-integrated software", "Git & GitHub workflows"].map((s, i) => (
            <li key={s} className="reveal relative">
              <span className="absolute -left-[31px] top-1 h-3 w-3 rounded-full bg-primary shadow-glow md:-top-[38px] md:left-0" />
              <p className="font-mono text-xs text-primary-glow">0{i + 1} · ongoing</p>
              <p className="mt-1 text-sm">{s}</p>
            </li>
          ))}
        </ol>
      </Section>

      {/* CONTACT */}
      <Section id="contact" eyebrow="07 / Contact" title="Let's Connect" subtitle="Have a project idea, internship opportunity, or a shared interest in software development? I'd be happy to connect.">
        <div className="grid gap-8 lg:grid-cols-[1fr_1.3fr]">
          <div className="reveal space-y-3">
            <ContactRow icon={<Mail size={18} />} label="Email" value={EMAIL} href={`mailto:${EMAIL}`} />
            <ContactRow icon={<Linkedin size={18} />} label="LinkedIn" value="prachi-katiyar" href={LINKEDIN} external />
            <ContactRow icon={<Github size={18} />} label="GitHub" value="Prachi-katiyar366" href={GITHUB} external />
            {SHOW_PHONE && <ContactRow icon={<Phone size={18} />} label="Phone" value={PHONE} href={`tel:${PHONE}`} />}
          </div>
          <ContactForm />
        </div>
      </Section>

      <footer className="border-t border-border px-6 py-8 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} Prachi Katiyar · Built with curiosity.
      </footer>
    </div>
  );
}

function ProjectCard({ icon, category, title, desc, points, tags, vision }: { icon: ReactNode; category: string; title: string; desc: string; points: string[]; tags: string[]; vision?: string }) {
  return (
    <article className="reveal glass group overflow-hidden rounded-2xl transition hover:-translate-y-1 hover:border-primary/60 hover:shadow-glow">
      <div className="bg-grid relative flex h-40 items-center justify-center border-b border-border bg-secondary text-primary-glow">
        <div className="absolute inset-0 bg-primary/10" />
        <span className="relative transition group-hover:scale-110">{icon}</span>
        <span className="absolute right-4 top-4 rounded-full border border-primary/50 bg-background/70 px-3 py-1 font-mono text-[11px] text-primary-glow">In Development</span>
      </div>
      <div className="p-6">
        <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground">{category}</p>
        <h3 className="mt-2 text-xl font-semibold">{title}</h3>
        {vision && <p className="mt-1 text-sm italic text-primary-glow">“{vision}”</p>}
        <p className="mt-3 text-sm text-muted-foreground">{desc}</p>
        <ul className="mt-4 grid gap-1 text-sm sm:grid-cols-2">{points.map((p) => <li key={p}>· {p}</li>)}</ul>
        <div className="mt-5 flex flex-wrap gap-2">{tags.map((t) => <span key={t} className="rounded-md bg-accent px-2.5 py-1 font-mono text-[11px]">{t}</span>)}</div>
        <p className="mt-5 text-xs text-muted-foreground">Project & source links coming soon.</p>
      </div>
    </article>
  );
}

function ContactRow({ icon, label, value, href, external }: { icon: ReactNode; label: string; value: string; href: string; external?: boolean }) {
  return (
    <a href={href} {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})} className="glass flex items-center gap-4 rounded-xl p-4 transition hover:border-primary/60">
      <span className="rounded-lg bg-accent p-2.5 text-primary-glow">{icon}</span>
      <span><span className="block text-xs text-muted-foreground">{label}</span><span className="break-all">{value}</span></span>
    </a>
  );
}

function ContactForm() {
  const [errors, setErrors] = useState<Partial<Record<"name"|"email"|"subject"|"message", string>>>({});
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const f = Object.fromEntries(new FormData(form)) as Record<"name"|"email"|"subject"|"message", string>;
    const errs: Partial<Record<"name"|"email"|"subject"|"message", string>> = {};
    (["name", "subject", "message"] as const).forEach((k) => { if (!f[k]?.trim()) errs[k] = "This field is required."; });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email || "")) errs.email = "Please enter a valid email.";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setStatus("sending");
    try {
      const res = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          service_id: "service_glq7cbs",
          template_id: "template_xia0i2d",
          user_id: "U3qSA9tdhvDi-F9i7",
          template_params: {
            name: f.name, email: f.email, subject: f.subject, message: f.message,
            from_name: f.name, from_email: f.email, reply_to: f.email, title: f.subject,
          },
        }),
      });
      if (!res.ok) throw new Error(await res.text());
      form.reset();
      setStatus("sent");
    } catch (err) {
      console.error("EmailJS error", err);
      setStatus("error");
    }
  }
  const field = "w-full rounded-lg border border-input bg-secondary px-4 py-3 text-sm outline-none transition focus:border-primary";
  return (
    <form onSubmit={submit} noValidate className="reveal glass grid gap-4 rounded-2xl p-6">
      {(["name", "email", "subject"] as const).map((k) => (
        <div key={k}>
          <label htmlFor={k} className="mb-1.5 block text-sm capitalize">{k}</label>
          <input id={k} name={k} type={k === "email" ? "email" : "text"} className={field} aria-invalid={!!errors[k]} />
          {errors[k] && <p className="mt-1 text-xs text-destructive">{errors[k]}</p>}
        </div>
      ))}
      <div>
        <label htmlFor="message" className="mb-1.5 block text-sm">Message</label>
        <textarea id="message" name="message" rows={5} className={field} aria-invalid={!!errors.message} />
        {errors.message && <p className="mt-1 text-xs text-destructive">{errors.message}</p>}
      </div>
      <button type="submit" disabled={status === "sending"} className="inline-flex items-center justify-center gap-2 rounded-lg bg-gradient-primary px-5 py-3 font-medium text-primary-foreground shadow-glow transition active:scale-95 disabled:opacity-60">
        {status === "sending" ? "Sending..." : "Send Message"} <ArrowRight size={16} />
      </button>
      {status === "sent" && <p className="text-sm text-success">Thanks! Your message has been sent.</p>}
      {status === "error" && <p className="text-sm text-destructive">Sorry, something went wrong. Please try again or email me directly.</p>}
    </form>
  );
}
